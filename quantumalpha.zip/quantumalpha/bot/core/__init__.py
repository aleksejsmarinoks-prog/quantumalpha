"""bot.core — QuantumAlpha core modules."""

__version__ = "1.0.0"
